#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function
# Main plugin file for CutsClear
# Compiled by iet5
import os
import sys
import glob
import time
import gettext
import types
# Add plugin directory to sys.path
plugin_path = os.path.dirname(os.path.realpath(__file__))
if plugin_path not in sys.path:
    sys.path.insert(0, plugin_path)
# ============================================================================
# Version Handling
# ============================================================================
version_file = os.path.join(plugin_path, "version.txt")
plugin_version = "Unknown"
try:
    if os.path.exists(version_file):
        with open(version_file, "r") as f:
            plugin_version = f.read().strip()
            if not plugin_version:
                plugin_version = "Unknown"
except Exception as e:
    print("[Plugin] Error reading version.txt: %s" % str(e))
    plugin_version = "Unknown"
# ============================================================================
# Python Compatibility Handling
# ============================================================================
# Handle imp/importlib for Python 2.7 and 3.12 compatibility
PY3 = sys.version_info[0] >= 3
if PY3:
    # Python 3.12+
    import importlib.util
    import importlib.machinery
    def load_module(name, path):
        """Load module for Python 3"""
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
else:
    # Python 2.7
    import imp
    def load_module(name, path):
        """Load module for Python 2"""
        return imp.load_source(name, path)
# ============================================================================
# Enigma2 Components Import
# ============================================================================
# Try to import Enigma2 components
HAS_ENIGMA2 = False
try:
    from Components.Language import language
    from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
    from Screens.MessageBox import MessageBox
    from Plugins.Plugin import PluginDescriptor
    from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigText
    from Screens.Screen import Screen
    from Components.ActionMap import ActionMap
    from Components.Label import Label
    from Components.FileList import FileList
    from Components.ConfigList import ConfigListScreen
    from Components.MenuList import MenuList
    from Components.config import configfile, getConfigListEntry
    from enigma import getDesktop, eTimer
    HAS_ENIGMA2 = True
except ImportError:
    HAS_ENIGMA2 = False
# ============================================================================
# Configuration Initialization
# ============================================================================
if HAS_ENIGMA2:
    # Initialize configuration if it doesn't exist
    if not hasattr(config.plugins, 'CutsClear'):
        config.plugins.CutsClear = ConfigSubsection()
    # Initialize configuration options
    if not hasattr(config.plugins.CutsClear, 'target_folder'):
        config.plugins.CutsClear.target_folder = ConfigText(default="/media/hdd/movie/", visible_width=50, fixed_size=False)
    if not hasattr(config.plugins.CutsClear, 'delete_all_files'):
        config.plugins.CutsClear.delete_all_files = ConfigYesNo(default=False)
    if not hasattr(config.plugins.CutsClear, 'select_specific_files'):
        config.plugins.CutsClear.select_specific_files = ConfigYesNo(default=False)
    # Additional configuration for plugin visibility
    if not hasattr(config.plugins.CutsClear, 'show_in_pluginmenu'):
        config.plugins.CutsClear.show_in_pluginmenu = ConfigYesNo(default=True)
    if not hasattr(config.plugins.CutsClear, 'show_in_extensions'):
        config.plugins.CutsClear.show_in_extensions = ConfigYesNo(default=True)
# ============================================================================
# Translation Setup
# ============================================================================
PluginLanguageDomain = "CutsClear"
PluginLanguagePath = "Extensions/CutsClear/locale"

if HAS_ENIGMA2:
    def localeInit():
        """Initialize translation"""
        try:
            lang = language.getLanguage()[:2]
            os.environ["LANGUAGE"] = lang
            gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))
        except Exception as e:
            print("[CutsClear] localeInit error: " + str(e))

    def _(txt):
        """Translation function"""
        try:
            t = gettext.dgettext(PluginLanguageDomain, txt)
            if t == txt:
                t = gettext.gettext(txt)
            return t
        except:
            return txt
    # Initialize translation
    localeInit()
    # Add callback for language change
    if hasattr(language, 'addCallback'):
        language.addCallback(localeInit)
else:
    def _(txt):
        """Fallback translation function"""
        return txt
# ============================================================================
# Helper Functions - Fixed to avoid counting files twice
# ============================================================================
def count_cuts_files(folder_path):
    """Count ONLY .cuts files in a folder (not other files) - FIXED: Avoid duplicate counting"""
    if not os.path.exists(folder_path):
        return 0
    count = 0
    try:
        # Use os.walk only to avoid duplicates
        for dirpath, dirnames, filenames in os.walk(folder_path):
            for filename in filenames:
                if filename.lower().endswith('.cuts'):
                    filepath = os.path.join(dirpath, filename)
                    if os.path.isfile(filepath):
                        count += 1
        return count
    except Exception as e:
        print("[CutsClear] Error counting .cuts files: {}".format(str(e)))
        return 0

def get_folder_size(folder_path):
    """Calculate total size of ONLY .cuts files in folder (ignore other files) - FIXED: Avoid duplicate counting"""
    total_size = 0
    if not os.path.exists(folder_path):
        return 0
    try:
        # Use os.walk only to avoid duplicates
        for dirpath, dirnames, filenames in os.walk(folder_path):
            for filename in filenames:
                if filename.lower().endswith('.cuts'):
                    filepath = os.path.join(dirpath, filename)
                    if os.path.isfile(filepath):
                        try:
                            total_size += os.path.getsize(filepath)
                        except:
                            pass
        return total_size
    except Exception as e:
        print("[CutsClear] Error calculating folder size: {}".format(str(e)))
        return 0

def format_size(size_bytes):
    """Format size for display"""
    if size_bytes == 0:
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return "{:.2f} {}".format(size_bytes, unit)
        size_bytes /= 1024.0
    return "{:.2f} TB".format(size_bytes)

def list_cuts_files(folder_path):
    """List all .cuts files in a folder and subdirectories (only .cuts files) - FIXED: Avoid duplicate listing"""
    cuts_files = []
    if not os.path.exists(folder_path):
        return cuts_files
    try:
        # Use os.walk only to avoid duplicates
        for dirpath, dirnames, filenames in os.walk(folder_path):
            for filename in filenames:
                if filename.lower().endswith('.cuts'):
                    filepath = os.path.join(dirpath, filename)
                    if os.path.isfile(filepath):
                        cuts_files.append(filepath)
        return cuts_files
    except Exception as e:
        print("[CutsClear] Error listing .cuts files: {}".format(str(e)))
        return []

def get_default_recording_path():
    """Get default recording path for various Enigma2 distributions"""
    default_paths = [
        "/media/hdd/movie/",
        "/hdd/movie/",
        "/media/usb/movie/",
        "/media/sda1/movie/",
        "/media/sdb1/movie/",
        "/movie/",
    ]
    for path in default_paths:
        if os.path.exists(path):
            return path
    # Return first path as default if none exist
    return default_paths[0]

def validate_cuts_file(file_path):
    """Validate if file is a .cuts file"""
    try:
        string_types = (str, unicode)
    except NameError:
        string_types = (str,)
    if not isinstance(file_path, string_types):
        return False
    return file_path.lower().endswith('.cuts') and os.path.isfile(file_path)

def validate_cuts_files(file_list):
    """Validate list of .cuts files"""
    valid_files = []
    for file_path in file_list:
        if validate_cuts_file(file_path):
            valid_files.append(file_path)
    return valid_files
# ============================================================================
# Logger Class
# ============================================================================
class Logger(object):
    """Logger class for CutsClear plugin"""
    def __init__(self, log_file="/tmp/CutsClear.log"):
        self.log_file = log_file
        self.max_size = 1024 * 1024

    def log_deletion_summary(self, operation, success_count, failed_count, total_size=0):
        """Log deletion summary"""
        try:
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            summary = "[{}] {} | Success: {} | Failed: {} | Size Freed: {}\n".format(
                timestamp, operation, success_count, failed_count, format_size(total_size))
            with open(self.log_file, 'a') as f:
                f.write(summary)
            print("CutsClear: " + summary.strip())
        except:
            pass
# ============================================================================
# Delete Engine Class
# ============================================================================
class DeleteEngine(object):
    """Engine for deleting .cuts files"""
    def __init__(self):
        self.logger = Logger()

    def delete_all_cuts(self, folder_path):
        """Delete all .cuts files in folder"""
        success_count = 0
        failed_count = 0
        total_size_freed = 0
        if not os.path.exists(folder_path):
            return success_count, failed_count, total_size_freed
        
        # Get all cuts files before deletion
        cuts_files = list_cuts_files(folder_path)
        print("[DeleteEngine] Found {} .cuts files to delete".format(len(cuts_files)))
        
        if len(cuts_files) == 0:
            return success_count, failed_count, total_size_freed
        
        for file_path in cuts_files:
            try:
                if os.path.isfile(file_path) and file_path.lower().endswith('.cuts'):
                    file_size = os.path.getsize(file_path)
                    os.remove(file_path)
                    success_count += 1
                    total_size_freed += file_size
                    print("[DeleteEngine] Deleted: {}".format(file_path))
                else:
                    failed_count += 1
                    print("[DeleteEngine] Failed: Not a .cuts file or doesn't exist: {}".format(file_path))
            except Exception as e:
                failed_count += 1
                print("[DeleteEngine] Error deleting {}: {}".format(file_path, str(e)))
        
        self.logger.log_deletion_summary("Delete All", success_count, failed_count, total_size_freed)
        return success_count, failed_count, total_size_freed

    def delete_selected_files(self, file_paths):
        """Delete selected files"""
        success_count = 0
        failed_count = 0
        total_size_freed = 0
        
        if not file_paths:
            return success_count, failed_count, total_size_freed
        
        for file_path in file_paths:
            try:
                if os.path.exists(file_path) and os.path.isfile(file_path) and file_path.lower().endswith('.cuts'):
                    file_size = os.path.getsize(file_path)
                    os.remove(file_path)
                    success_count += 1
                    total_size_freed += file_size
                    print("[DeleteEngine] Deleted: {}".format(file_path))
                else:
                    failed_count += 1
                    print("[DeleteEngine] Failed: Not a valid .cuts file: {}".format(file_path))
            except Exception as e:
                failed_count += 1
                print("[DeleteEngine] Error deleting {}: {}".format(file_path, str(e)))
        
        self.logger.log_deletion_summary("Delete Selected", success_count, failed_count, total_size_freed)
        return success_count, failed_count, total_size_freed

    def get_folder_stats(self, folder_path):
        """Get statistics about cuts files in a folder"""
        if not os.path.exists(folder_path):
            return {"exists": False, "file_count": 0, "total_size": 0, "formatted_size": "0 B"}
        
        files = list_cuts_files(folder_path)
        total_size = get_folder_size(folder_path)
        
        print("[DeleteEngine] get_folder_stats: {} files, {} bytes".format(len(files), total_size))
        
        return {
            "exists": True,
            "file_count": len(files),
            "total_size": total_size,
            "formatted_size": format_size(total_size)
        }
# ============================================================================
# Custom MessageBox
# ============================================================================
class CustomMessageBox(Screen):
    """Custom MessageBox with larger buttons and font for yes/no - Smaller size"""

    desktop = getDesktop(0)
    if desktop and desktop.size().width() >= 1920:
        # For HD screens (1920x1080) - Smaller size
        skin = """
        <screen name="CustomMessageBox" position="center,center" size="900,350" title="Confirm Deletion" backgroundColor="#000000">
            <widget name="text" position="30,30" size="840,180" font="Regular;28" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#000000" transparent="1" />
            <widget name="key_red" position="150,230" size="250,70" font="Regular;32" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="500,230" size="250,70" font="Regular;32" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
        </screen>
        """
    else:
        # For SD screens (1280x720) - Smaller size
        skin = """
        <screen name="CustomMessageBox" position="center,center" size="650,250" title="Confirm Deletion" backgroundColor="#000000">
            <widget name="text" position="20,20" size="610,110" font="Regular;22" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#000000" transparent="1" />
            <widget name="key_red" position="100,150" size="200,50" font="Regular;26" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="350,150" size="200,50" font="Regular;26" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
        </screen>
        """

    def __init__(self, session, text, type=MessageBox.TYPE_YESNO, timeout=-1):
        Screen.__init__(self, session)
        self.type = type
        self.text = text
        self.result = None
        # Shorten the message if it's too long
        if len(text) > 150:
            lines = text.split('\n')
            if len(lines) > 4:
                short_text = '\n'.join(lines[:3]) + "\n..."
            else:
                short_text = text
        else:
            short_text = text
        self["text"] = Label(short_text)
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("OK")
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.keyCancel,
            "red": self.keyCancel,
            "green": self.keyOK,
            "ok": self.keyOK,
        }, -1)
        if timeout > 0:
            self.timer = eTimer()
            self.timer.callback.append(self.timeoutAction)
            self.timer.start(timeout * 1000, True)
        else:
            self.timer = None

    def timeoutAction(self):
        """Handle timeout"""
        self.close(False)
    
    def keyCancel(self):
        """Cancel action"""
        self.close(False)
    
    def keyOK(self):
        """OK action"""
        self.close(True)
# ============================================================================
# Enhanced Folder Select Screen
# ============================================================================
class FolderSelectScreen(Screen):
    """Enhanced Screen for selecting a folder with smart selection"""
    
    # Get screen resolution
    desktop = getDesktop(0)
    if desktop and desktop.size().width() >= 1920:
        skin = """
        <screen name="FolderSelectScreen" position="center,center" size="1920,1080" title="Select Folder">
            <widget name="current_folder" position="50,50" size="1820,80" font="Regular;36" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" halign="center" valign="center" />
            <widget name="filelist" position="50,150" size="1820,800" scrollbarMode="showOnDemand" />
            <widget name="instructions" position="50,970" size="1820,50" font="Regular;28" foregroundColor="#00ff00" backgroundColor="#000000" transparent="1" halign="center" />
            <widget name="key_red" position="100,1020" size="400,60" font="Regular;32" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="600,1020" size="400,60" font="Regular;32" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
        </screen>
        """
    else:
        skin = """
        <screen name="FolderSelectScreen" position="center,center" size="1280,720" title="Select Folder">
            <widget name="current_folder" position="30,30" size="1220,50" font="Regular;22" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" halign="center" valign="center" />
            <widget name="filelist" position="30,100" size="1220,520" scrollbarMode="showOnDemand" />
            <widget name="instructions" position="30,640" size="1220,30" font="Regular;18" foregroundColor="#00ff00" backgroundColor="#000000" transparent="1" halign="center" />
            <widget name="key_red" position="80,680" size="280,45" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="370,680" size="280,45" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
        </screen>
        """
    
    def __init__(self, session, currDir="/media/hdd/movie/"):
        Screen.__init__(self, session)
        self.session = session
        print("[FolderSelect] Initial directory received:", currDir)
        if not currDir or not isinstance(currDir, str):
            currDir = "/media/hdd/movie/"
        currDir = currDir.strip()
        # Clean the path from tuple representation
        currDir = self.clean_path(currDir)
        # Ensure path exists
        if not os.path.exists(currDir):
            if os.path.exists("/media/hdd/movie/"):
                currDir = "/media/hdd/movie/"
            elif os.path.exists("/media/hdd/"):
                currDir = "/media/hdd/"
            elif os.path.exists("/media/"):
                currDir = "/media/"
            else:
                currDir = "/"
        # Ensure path ends with slash
        if not currDir.endswith('/'):
            currDir += '/'
        self.current_directory = currDir
        print("[FolderSelect] Creating FileList with path:", currDir)
        # Create FileList
        try:
            self["filelist"] = FileList(currDir, showDirectories=True, showFiles=True, showMountpoints=True)
            print("[FolderSelect] FileList created successfully")
        except Exception as e:
            print("[FolderSelect] Error creating FileList:", str(e))
            self["filelist"] = FileList("/", showDirectories=True, showFiles=True)
            self.current_directory = "/"
        self["current_folder"] = Label("Current Folder: " + currDir)
        # UI elements
        self["instructions"] = Label("Press GREEN to select folder | Press OK to enter folder")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Select Folder")
        # Action map - Green button works for both cases
        self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "OkCancelActions"], {
            "back": self.exit,
            "red": self.exit,
            "green": self.selectFolder,
            "ok": self.enterFolder,
            "up": self["filelist"].up,
            "down": self["filelist"].down,
            "left": self["filelist"].pageUp,
            "right": self["filelist"].pageDown,
            "cancel": self.exit,
        }, -1)
        self["filelist"].onSelectionChanged.append(self.updateFolderDisplay)

    def clean_path(self, path):
        """Clean path from tuple representation"""
        if not isinstance(path, str):
            path = str(path)
        # Remove any tuple representation
        if "', True," in path or "',True," in path:
            if "', True," in path:
                path = path.split("', True,")[0]
                path = path.replace("('", "").replace("'", "")
            elif "',True," in path:
                path = path.split("',True,")[0]
                path = path.replace("('", "").replace("'", "")
        # Remove any other unwanted characters
        unwanted_patterns = [
            "', True)", "',True)", "', False)", "',False)", 
            "', None)", "',None)", "', 'test')", "', 'test')/"
        ]
        for pattern in unwanted_patterns:
            if pattern in path:
                path = path.split(pattern)[0]
                path = path.replace("('", "").replace("'", "")
        return path.strip()

    def updateFolderDisplay(self):
        """Update the folder display when selection changes"""
        try:
            current_dir = self["filelist"].getCurrentDirectory()
            if current_dir:
                # Clean the path
                current_dir = self.clean_path(str(current_dir))
                self.current_directory = current_dir
                display_text = "Current Folder: " + current_dir
                if len(display_text) > 100:
                    display_text = "Folder: ..." + current_dir[-80:]
                self["current_folder"].setText(display_text)
        except:
            pass

    def enterFolder(self):
        """Handle OK button press - Enter selected folder"""
        try:
            # Get current selection
            current = self["filelist"].getCurrent()
            if current:
                selected_item = current[0]
                is_dir = current[1]
                if is_dir:
                    # Extract the path from the selected item
                    if hasattr(selected_item, 'getPath'):
                        new_path = selected_item.getPath()
                    elif hasattr(selected_item, 'path'):
                        new_path = selected_item.path
                    else:
                        new_path = str(selected_item)
                    # Clean the path
                    new_path = self.clean_path(new_path)
                    # Ensure it's a directory path
                    if not new_path.endswith('/'):
                        new_path += '/'
                    print("[FolderSelect] OK pressed, entering directory:", new_path)
                    # Try to change directory
                    try:
                        self["filelist"].changeDir(new_path)
                        updated_dir = self["filelist"].getCurrentDirectory()
                        if updated_dir:
                            updated_dir = self.clean_path(str(updated_dir))
                            self.current_directory = updated_dir
                            display_text = "Current Folder: " + updated_dir
                            if len(display_text) > 100:
                                display_text = "Folder: ..." + updated_dir[-80:]
                            self["current_folder"].setText(display_text)
                            print("[FolderSelect] Successfully entered:", updated_dir)
                    except Exception as e:
                        print("[FolderSelect] Error changing directory:", str(e))
                        # Fallback: create new FileList
                        if os.path.isdir(new_path):
                            self["filelist"] = FileList(new_path, showDirectories=True, showFiles=False)
                            self.current_directory = new_path
                            display_text = "Current Folder: " + new_path
                            if len(display_text) > 100:
                                display_text = "Folder: ..." + new_path[-80:]
                            self["current_folder"].setText(display_text)
        except Exception as e:
            print("[FolderSelect] Enter folder error:", str(e))

    def selectFolder(self):
        """Handle Select (Green) button press - Smart selection"""
        try:
            # Get current selection
            current = self["filelist"].getCurrent()
            if current:
                selected_item = current[0]
                is_dir = current[1]
                if is_dir:
                    # If a folder is highlighted, save that folder
                    if hasattr(selected_item, 'getPath'):
                        selected_path = selected_item.getPath()
                    elif hasattr(selected_item, 'path'):
                        selected_path = selected_item.path
                    else:
                        selected_path = str(selected_item)
                    # Clean the path
                    selected_path = self.clean_path(selected_path)
                    # Ensure it's a directory path
                    if not selected_path.endswith('/'):
                        selected_path += '/'
                    print("[FolderSelect] Green pressed, saving highlighted folder:", selected_path)
                    self.close(selected_path)
                else:
                    # This shouldn't happen since we only show directories
                    print("[FolderSelect] Selected item is not a directory, saving current folder")
                    self.saveCurrentFolder()
            else:
                # No selection, save current folder
                print("[FolderSelect] No selection, saving current folder")
                self.saveCurrentFolder()
        except Exception as e:
            print("[FolderSelect] selectFolder error:", str(e))
            self.saveCurrentFolder()
    
    def saveCurrentFolder(self):
        """Save the current directory path"""
        try:
            # Get the current directory
            current_dir = self["filelist"].getCurrentDirectory()
            if not current_dir:
                current_dir = self.current_directory
            # Clean the path
            current_dir = self.clean_path(str(current_dir))
            # Ensure it ends with slash
            if not current_dir.endswith('/'):
                current_dir += '/'
            print("[FolderSelect] Saving current folder:", current_dir)
            self.close(current_dir)
        except Exception as e:
            print("[FolderSelect] saveCurrentFolder error:", str(e))
            self.close(self.current_directory)
    
    def exit(self):
        """Handle Cancel/Exit - Fixed to prevent crash"""
        try:
            self.close(None)
        except:
            pass
# ============================================================================
# File Select Screen - Fixed to avoid duplicate file listing
# ============================================================================
class FileSelectScreen(Screen):
    """Screen for selecting files for deletion with Yes/No selection and better layout"""
    
    # Get screen resolution
    desktop = getDesktop(0)
    if desktop and desktop.size().width() >= 1920:
        skin = """
        <screen name="FileSelectScreen" position="0,60" size="1920,1080" title="Select .cuts Files for Deletion" backgroundColor="#000000">
            <!-- Folder and Files Info at Top -->
            <widget name="folder_header" position="50,20" size="1820,65" font="Regular;32" foregroundColor="#00ffff" backgroundColor="#333333" transparent="0" halign="center" valign="center" />
            <widget name="files_info" position="50,110" size="1820,60" font="Regular;30" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" halign="center" valign="center" />
            <!-- File List with Yes/No Selection -->
            <widget name="filelist" position="50,190" size="1820,650" itemHeight="60" font="Regular;30" scrollbarMode="showOnDemand" backgroundColor="#222222" foregroundColor="#ffffff" />
            <!-- Selection Count -->
            <widget name="count" position="50,860" size="1820,40" font="Regular;30" halign="center" valign="center" foregroundColor="#ffff00" transparent="1" />
            <!-- Buttons -->
            <widget name="key_red" position="200,920" size="400,55" font="Regular;35" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="700,920" size="400,55" font="Regular;35" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
            <widget name="key_blue" position="1200,920" size="400,55" font="Regular;35" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000ff" transparent="0" />
        </screen>
        """
    else:
        skin = """
        <screen name="FileSelectScreen" position="0,60" size="1280,700" title="Select .cuts Files for Deletion" backgroundColor="#000000">
            <!-- Folder and Files Info at Top -->
            <widget name="folder_header" position="30,20" size="1220,40" font="Regular;26" foregroundColor="#00ffff" backgroundColor="#333333" transparent="0" halign="center" valign="center" />
            <widget name="files_info" position="30,70" size="1220,40" font="Regular;24" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" halign="center" valign="center" />
            <!-- File List with Yes/No Selection -->
            <widget name="filelist" position="30,120" size="1220,380" itemHeight="54" font="Regular;34" scrollbarMode="showOnDemand" backgroundColor="#222222" foregroundColor="#ffffff" />
            <!-- Selection Count -->
            <widget name="count" position="30,515" size="1220,30" font="Regular;24" halign="center" valign="center" foregroundColor="#ffff00" transparent="1" />
            <!-- Buttons -->
            <widget name="key_red" position="100,560" size="280,40" font="Regular;25" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="480,560" size="280,40" font="Regular;25" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
            <widget name="key_blue" position="860,560" size="280,40" font="Regular;25" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000ff" transparent="0" />
        </screen>
        """
    
    def __init__(self, session, folder_path):
        Screen.__init__(self, session)
        self.session = session
        self.folder_path = str(folder_path).strip()
        self.selected_files = []
        self.file_list = []
        self.file_status = {}
        self.current_index = 0
        # Load .cuts files only
        self.load_cuts_files()
        # Initialize UI elements
        self["folder_header"] = Label("")
        self["files_info"] = Label("")
        self["filelist"] = MenuList([], enableWrapAround=True)
        self["count"] = Label("")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Confirm")
        self["key_blue"] = Label("Toggle All")
        # Update folder and files info
        self.update_folder_info()
        # Now update the display
        self.update_file_list_display()
        # Action map should be after initializing all elements
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.confirm_selection,
            "blue": self.toggle_all,
            "ok": self.toggle_selection,
            "up": self.up,
            "down": self.down,
        }, -1)
        # Track selection changes
        self["filelist"].onSelectionChanged.append(self.onSelectionChanged)
    
    def update_folder_info(self):
        """Update folder and files information at top of screen"""
        try:
            # Display folder path
            folder_display = "Folder: " + self.folder_path
            if len(folder_display) > 70:
                folder_display = "Folder: ..." + self.folder_path[-60:]
            self["folder_header"].setText(folder_display)
            # Count ONLY .cuts files and calculate size
            file_count = count_cuts_files(self.folder_path)
            total_size = get_folder_size(self.folder_path)
            size_text = format_size(total_size)
            # Display files info
            files_info = "Found: {} .cuts file(s) | Total size: {}".format(file_count, size_text)
            self["files_info"].setText(files_info)
        except Exception as e:
            print("[FileSelect] Error updating folder info: {}".format(str(e)))
            self["folder_header"].setText("Folder: Error reading path")
            self["files_info"].setText("Found: 0 .cuts files | Total size: 0 B")
    
    def onSelectionChanged(self):
        """Track current selection index"""
        self.current_index = self["filelist"].getSelectedIndex()
    
    def load_cuts_files(self):
        """Load .cuts files from folder - only .cuts files are loaded, NO DUPLICATES"""
        if not os.path.exists(self.folder_path):
            return
        
        # Use list_cuts_files which now avoids duplicates
        files = list_cuts_files(self.folder_path)
        print("[FileSelect] Loaded {} .cuts files (no duplicates)".format(len(files)))
        
        # Sort files by full path to maintain consistent order
        files.sort(key=lambda x: x.lower())
        
        for file_path in files:
            if os.path.isfile(file_path):
                self.file_list.append(file_path)  # Store full path
                self.file_status[file_path] = False  # Default: No

    def update_file_list_display(self):
        """Update the display list with current status"""
        display_list = []
        for file_path in self.file_list:
            status = self.file_status.get(file_path, False)
            filename = os.path.basename(file_path)
            # Display format with simple text
            if status:
                # Selected for deletion - marked with [YES]
                display_text = "[YES] " + filename
            else:
                # Not selected - marked with [NO]
                display_text = "[NO]  " + filename
            display_list.append(display_text)
        # Update count
        selected_count = sum(1 for status in self.file_status.values() if status)
        total_count = len(self.file_list)
        self["count"].setText("Selected: {} / {} files".format(selected_count, total_count))
        # Update filelist
        self["filelist"].setList(display_list)
        # Restore selection position
        if self.current_index < len(display_list):
            try:
                self["filelist"].moveToIndex(self.current_index)
            except:
                self.restore_selection(self.current_index)

    def restore_selection(self, index):
        """Manually restore selection"""
        try:
            # Go to top first
            self["filelist"].top()
            # Then move down to the desired index
            for i in range(min(index, len(self.file_list))):
                self["filelist"].down()
        except:
            pass
    
    def toggle_selection(self):
        """Toggle file selection between Yes/No"""
        selected_index = self["filelist"].getSelectedIndex()
        if 0 <= selected_index < len(self.file_list):
            file_path = self.file_list[selected_index]
            # Toggle status
            current_status = self.file_status.get(file_path, False)
            self.file_status[file_path] = not current_status
            # Update the display with new status
            self.update_file_list_display()
            # Keep selection on the same item
            try:
                self["filelist"].moveToIndex(selected_index)
            except:
                self.restore_selection(selected_index)
    
    def toggle_all(self):
        """Toggle all files between YES/NO"""
        if not self.file_list:
            return
        # Check if all files are selected (YES)
        all_selected = all(status for status in self.file_status.values())
        # Toggle all files
        for file_path in self.file_list:
            self.file_status[file_path] = not all_selected
        # Update display
        self.update_file_list_display()
    
    def up(self):
        """Move selection up"""
        self["filelist"].up()
    
    def down(self):
        """Move selection down"""
        self["filelist"].down()
    
    def exit(self):
        """Exit without selection - Fixed to prevent crash"""
        try:
            self.close([])
        except:
            pass

    def confirm_selection(self):
        """Confirm selection with confirmation dialog"""
        # Get files selected for deletion (status = Yes)
        selected_files = [file_path for file_path, status in self.file_status.items() if status]
        if not selected_files:
            # Use safe method to show message without causing crash
            try:
                self.session.open(MessageBox, "No files selected for deletion.", MessageBox.TYPE_INFO, timeout=3)
            except:
                pass
            return
        # Show confirmation dialog with number of files
        message = "Are you sure you want to delete {} .cuts file(s)?\n\nPress OK to confirm deletion or Cancel to go back.".format(len(selected_files))
        # Open confirmation dialog - Using CustomMessageBox
        self.session.openWithCallback(self.confirm_callback,
                                      CustomMessageBox,
                                      message)
    
    def confirm_callback(self, confirmed):
        """Callback for confirmation dialog"""
        if confirmed:
            # Get files selected for deletion (status = Yes)
            selected_files = [file_path for file_path, status in self.file_status.items() if status]
            # Close screen and return selected files (already full paths)
            self.close(selected_files)
        else:
            # User cancelled, stay in the screen
            pass
# ============================================================================
# Main Screen - Improved with forced refresh after deletion
# ============================================================================
class CutsClearMain(ConfigListScreen, Screen):
    """Main screen for CutsClear plugin"""
    desktop = getDesktop(0)
    if desktop and desktop.size().width() >= 1920:
        # Modified HD skin: adjusted version widget position and size
        skin = """
        <screen name="CutsClearMain" position="center,center" size="1920,1080" title="CutsClear">
            <widget name="header" position="20,20" size="800,60" font="Regular;35" foregroundColor="#ffffff" backgroundColor="background" halign="left" />
            <widget name="version" position="850,20" size="1050,60" font="Regular;35" foregroundColor="#ffffff" backgroundColor="background" halign="right" />
            <widget name="separator" position="20,100" size="1880,3" backgroundColor="#444444" />
            <!-- Current Folder Display - Larger and more prominent -->
            <widget name="folder_label" position="100,130" size="300,50" font="Regular;30" foregroundColor="#ffff00" transparent="1" />
            <widget name="folder_path" position="400,130" size="1420,50" font="Regular;30" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Files Info Display -->
            <widget name="files_label" position="100,200" size="300,50" font="Regular;30" foregroundColor="#ffff00" transparent="1" />
            <widget name="files_count" position="400,200" size="300,50" font="Regular;30" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Size Info Display -->
            <widget name="size_label" position="100,270" size="300,50" font="Regular;30" foregroundColor="#ffff00" transparent="1" />
            <widget name="size_info" position="400,270" size="300,50" font="Regular;30" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Options Area - Moved down to make room for folder info -->
            <widget name="config" position="100,350" size="1720,250" itemHeight="45" scrollbarMode="showOnDemand" backgroundColor="#111111" foregroundColor="#ffffff" />
            <!-- Help Area -->
            <widget name="help" position="100,620" size="1720,200" font="Regular;26" halign="left" valign="top" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" />
            <!-- Buttons -->
            <widget name="key_red" position="100,850" size="300,60" font="Regular;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="450,850" size="300,60" font="Regular;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
            <widget name="key_yellow" position="800,850" size="300,60" font="Regular;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ffff00" transparent="0" />
            <widget name="key_blue" position="1150,850" size="300,60" font="Regular;30" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000ff" transparent="0" />
        </screen>
        """
    else:
        skin = """
        <screen name="CutsClearMain" position="center,center" size="1280,720" title="CutsClear">
            <widget name="header" position="10,10" size="600,40" font="Regular;25" foregroundColor="#ffffff" backgroundColor="background" halign="left" />
            <widget name="version" position="620,10" size="650,40" font="Regular;25" foregroundColor="#ffffff" backgroundColor="background" halign="right" />
            <widget name="separator" position="10,60" size="1260,2" backgroundColor="#444444" />
            <!-- Current Folder Display - Larger and more prominent -->
            <widget name="folder_label" position="80,80" size="200,30" font="Regular;20" foregroundColor="#ffff00" transparent="1" />
            <widget name="folder_path" position="280,80" size="920,30" font="Regular;20" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Files Info Display -->
            <widget name="files_label" position="80,120" size="200,30" font="Regular;20" foregroundColor="#ffff00" transparent="1" />
            <widget name="files_count" position="280,120" size="200,30" font="Regular;20" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Size Info Display -->
            <widget name="size_label" position="80,160" size="200,30" font="Regular;20" foregroundColor="#ffff00" transparent="1" />
            <widget name="size_info" position="280,160" size="200,30" font="Regular;20" foregroundColor="#00ff00" backgroundColor="#222222" transparent="0" />
            <!-- Options Area -->
            <widget name="config" position="80,210" size="1120,180" itemHeight="30" scrollbarMode="showOnDemand" backgroundColor="#111111" foregroundColor="#ffffff" />
            <!-- Help Area -->
            <widget name="help" position="80,410" size="1120,150" font="Regular;18" halign="left" valign="top" foregroundColor="#ffff00" backgroundColor="#222222" transparent="0" />
            <!-- Buttons -->
            <widget name="key_red" position="80,580" size="200,45" font="Regular;22" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ff0000" transparent="0" />
            <widget name="key_green" position="300,580" size="200,45" font="Regular;22" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" />
            <widget name="key_yellow" position="520,580" size="200,45" font="Regular;22" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#ffff00" transparent="0" />
            <widget name="key_blue" position="740,580" size="200,45" font="Regular;22" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000ff" transparent="0" />
        </screen>
        """
    
    def __init__(self, session):
        # Initialize Screen first
        Screen.__init__(self, session)
        self.session = session
        # Define helplist before ConfigListScreen
        self["helplist"] = Label("")
        # Set up the options list
        self.list = [
            getConfigListEntry(_("Delete ALL .cuts files"), config.plugins.CutsClear.delete_all_files),
            getConfigListEntry(_("Select specific .cuts files"), config.plugins.CutsClear.select_specific_files),
        ]
        # Initialize ConfigListScreen
        ConfigListScreen.__init__(self, self.list, session=session)
        # Delete engine and update status - Now using local DeleteEngine
        self.engine = DeleteEngine()
        self.is_updating = False
        # Initialize UI elements
        self["header"] = Label("CutsClear by iet5")
        self["version"] = Label("Version " + plugin_version)
        self["separator"] = Label("")
        # Current folder display
        self["folder_label"] = Label("Current Folder:")
        self["folder_path"] = Label("")
        # Files info
        self["files_label"] = Label(".cuts Files Found:")
        self["files_count"] = Label("")
        # Size info
        self["size_label"] = Label("Total Size (.cuts only):")
        self["size_info"] = Label("")
        self["help"] = Label("Select an option and press Execute (Green) to delete .cuts files")
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Execute")
        self["key_yellow"] = Label("Select Files")
        self["key_blue"] = Label("Browse Folder")
        # Action map
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.execute_deletion,
            "yellow": self.open_file_select,
            "blue": self.browse_folder,
            "ok": self.ok_pressed,
        }, -1)
        # Connect config changed signal
        self["config"].onSelectionChanged.append(self.update_help_text)
        # Set initial help text and update info
        self.update_folder_info()
        self.update_help_text()

    def ok_pressed(self):
        """Handle OK button press on config items"""
        current = self["config"].getCurrent()
        if current:
            # Toggle the current selection
            if current[1] == config.plugins.CutsClear.delete_all_files:
                config.plugins.CutsClear.delete_all_files.value = not config.plugins.CutsClear.delete_all_files.value
                if config.plugins.CutsClear.delete_all_files.value:
                    config.plugins.CutsClear.select_specific_files.value = False
            elif current[1] == config.plugins.CutsClear.select_specific_files:
                config.plugins.CutsClear.select_specific_files.value = not config.plugins.CutsClear.select_specific_files.value
                if config.plugins.CutsClear.select_specific_files.value:
                    config.plugins.CutsClear.delete_all_files.value = False
            # Update the display
            self.update_help_text()
    
    def update_folder_info(self):
        """Update folder information display - FORCED REFRESH"""
        try:
            target_dir = config.plugins.CutsClear.target_folder.value
            
            # Force refresh by calling functions directly
            file_count = count_cuts_files(target_dir)
            total_size = get_folder_size(target_dir)
            size_text = format_size(total_size)
            
            print("[Main] update_folder_info: {} .cuts files, {} bytes".format(file_count, total_size))
            
            # Update folder path - show full path
            folder_display = target_dir
            if len(folder_display) > 60:
                folder_display = "..." + target_dir[-57:]
            self["folder_path"].setText(folder_display)
            
            # Update files count
            self["files_count"].setText("{} .cuts file(s)".format(file_count))
            
            # Update size info
            self["size_info"].setText(size_text)
            
            # Force GUI refresh
            self["files_count"].hide()
            self["files_count"].show()
            self["size_info"].hide()
            self["size_info"].show()
            
        except Exception as e:
            print("[CutsClear] Error updating folder info: {}".format(str(e)))
            self["folder_path"].setText("Error reading folder")
            self["files_count"].setText("0 files")
            self["size_info"].setText("0 B")

    def update_help_text(self):
        """Update help text based on current selection"""
        try:
            current = self["config"].getCurrent()
            if not current:
                return
            target_dir = config.plugins.CutsClear.target_folder.value
            file_count = count_cuts_files(target_dir)
            total_size = get_folder_size(target_dir)
            size_text = format_size(total_size)
            # Make options mutually exclusive
            if current[1] == config.plugins.CutsClear.delete_all_files:
                if current[1].value:
                    config.plugins.CutsClear.select_specific_files.value = False
                help_text = _("Delete all .cuts files:\n")
                help_text += _("Will delete all {} .cuts files in folder\n").format(file_count)
                help_text += _("Size to be freed: {}\n").format(size_text)
                help_text += _("This action cannot be undone!\n")
                help_text += _("Make sure you have backups if needed")
                self["help"].setText(help_text)
            elif current[1] == config.plugins.CutsClear.select_specific_files:
                if current[1].value:
                    config.plugins.CutsClear.delete_all_files.value = False
                help_text = _("Select specific .cuts files:\n")
                help_text += _("Will open file selection screen\n")
                help_text += _("You can choose .cuts files to delete\n")
                help_text += _("Available .cuts files: {} file(s)\n").format(file_count)
                help_text += _("Total size available: {}\n").format(size_text)
                help_text += _("Press yellow button to open file selector")
                self["help"].setText(help_text)
            else:
                # General help when no option selected
                help_text = _("Select a deletion option:\n")
                help_text += _("Current folder: {}\n").format(target_dir)
                help_text += _(".cuts files in folder: {} file(s)\n").format(file_count)
                help_text += _("Total size (.cuts only): {}\n").format(size_text)
                help_text += _("Press blue button to browse another folder\n")
                help_text += _("Press yellow to directly select .cuts files")
                self["help"].setText(help_text)
        except Exception as e:
            print("[CutsClear] Error updating help text: {}".format(str(e)))
            self["help"].setText("Error loading help information")
    
    def open_file_select(self):
        """Open file selection screen directly (Yellow button)"""
        try:
            target_dir = config.plugins.CutsClear.target_folder.value
            # Check if folder exists
            if not os.path.exists(target_dir):
                self.show_safe_message("The target folder does not exist.")
                return
            file_count = count_cuts_files(target_dir)
            if file_count == 0:
                self.show_safe_message("No .cuts files found in this folder.")
                return
            # Set select specific files to True and unselect delete all
            config.plugins.CutsClear.select_specific_files.value = True
            config.plugins.CutsClear.delete_all_files.value = False
            # Update display
            self.update_help_text()
            # Open file selection screen
            self.session.openWithCallback(self.delete_selected_callback,
                                         FileSelectScreen,
                                         target_dir)
        except Exception as e:
            print("[CutsClear] Error opening file select: {}".format(str(e)))
            self.show_safe_message("Error: " + str(e))
    
    def show_safe_message(self, message):
        """Safely show a message without causing crash"""
        try:
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
        except Exception as e:
            print("[CutsClear] Failed to show message: {} - {}".format(message, str(e)))
    
    def exit(self):
        """Exit the plugin - Fixed to prevent crash"""
        try:
            config.plugins.CutsClear.save()
            configfile.save()
            self.close()
        except:
            self.close()
    
    def execute_deletion(self):
        """Execute deletion based on selected option"""
        try:
            target_dir = config.plugins.CutsClear.target_folder.value
            # Check if target folder exists
            if not os.path.exists(target_dir):
                self.show_safe_message("The specified folder does not exist.")
                return
            # Check which option is selected
            if config.plugins.CutsClear.delete_all_files.value:
                self.delete_all_files()
            elif config.plugins.CutsClear.select_specific_files.value:
                self.select_files()
            else:
                self.show_safe_message("Please select a deletion option first.")
        except Exception as e:
            print("[CutsClear] Error in execute_deletion: {}".format(str(e)))
    
    def delete_all_files(self):
        """Delete all .cuts files in current folder"""
        try:
            target_dir = config.plugins.CutsClear.target_folder.value
            count = count_cuts_files(target_dir)
            if count == 0:
                self.show_safe_message("No .cuts files found in this folder.")
                return
            # Calculate size to be freed
            total_size = get_folder_size(target_dir)
            size_text = format_size(total_size)
            # Ask for confirmation
            message = "Are you sure you want to delete all {} .cuts files?\n\nTotal size: {}\n\nThis action cannot be undone!".format(count, size_text)
            self.session.openWithCallback(self.delete_all_callback,
                                         CustomMessageBox,
                                         message)
        except Exception as e:
            print("[CutsClear] Error in delete_all_files: {}".format(str(e)))
    
    def delete_all_callback(self, confirmed):
        """Callback for delete all confirmation"""
        if confirmed:
            try:
                target_dir = config.plugins.CutsClear.target_folder.value
                success, failed, total_size = self.engine.delete_all_cuts(target_dir)
                # Force refresh folder info after deletion
                self.update_folder_info()
                # Force refresh help text
                self.update_help_text()
                # Show completion message
                message = "Deletion completed:\n"
                message += "Deleted: {} .cuts file(s)\n".format(success)
                message += "Failed to delete: {} file(s)\n".format(failed)
                message += "Size freed: {}".format(format_size(total_size))
                self.show_safe_message(message)
            except Exception as e:
                print("[CutsClear] Error in delete_all_callback: {}".format(str(e)))
                self.show_safe_message("Error during deletion: " + str(e))
    
    def select_files(self):
        """Open file selection screen"""
        try:
            target_dir = config.plugins.CutsClear.target_folder.value
            if count_cuts_files(target_dir) == 0:
                self.show_safe_message("No .cuts files found in this folder.")
                return
            self.session.openWithCallback(self.delete_selected_callback,
                                         FileSelectScreen,
                                         target_dir)
        except Exception as e:
            print("[CutsClear] Error in select_files: {}".format(str(e)))
    
    def delete_selected_callback(self, file_paths):
        """Callback for selected files deletion"""
        if file_paths:
            try:
                # Show processing message
                self.show_safe_message("Deleting {} .cuts file(s)...".format(len(file_paths)))
                # Delete files
                success, failed, total_size = self.engine.delete_selected_files(file_paths)
                # Force refresh folder info after deletion
                self.update_folder_info()
                # Force refresh help text
                self.update_help_text()
                # Show completion message
                message = "Selective deletion completed:\n"
                message += "Deleted: {} .cuts file(s)\n".format(success)
                message += "Failed to delete: {} file(s)\n".format(failed)
                message += "Size freed: {}".format(format_size(total_size))
                self.show_safe_message(message)
            except Exception as e:
                print("[CutsClear] Error in delete_selected_callback: {}".format(str(e)))
                self.show_safe_message("Error during deletion: " + str(e))
        else:
            # User cancelled or no files selected
            pass
    
    def browse_folder(self):
        """Open folder browser"""
        try:
            start_dir = config.plugins.CutsClear.target_folder.value
            print("[Main] Opening folder browser from:", start_dir)
            self.session.openWithCallback(self.folder_selected_callback,
                                         FolderSelectScreen,
                                         start_dir)
        except Exception as e:
            print("[CutsClear] Error in browse_folder: {}".format(str(e)))
    
    def folder_selected_callback(self, selected_path):
        """Callback for folder selection"""
        if selected_path:
            try:
                print("[Main] Raw folder selected:", selected_path)
                # Clean the path
                selected_path = str(selected_path).strip()
                # Remove tuple representation if present
                if "', True)" in selected_path or "',True)" in selected_path:
                    if "', True)" in selected_path:
                        selected_path = selected_path.split("', True)")[0]
                        selected_path = selected_path.replace("('", "").replace("'", "")
                    elif "',True)" in selected_path:
                        selected_path = selected_path.split("',True)")[0]
                        selected_path = selected_path.replace("('", "").replace("'", "")
                # Remove any other unwanted patterns
                unwanted_patterns = [
                    "', False)", "',False)", "', None)", "',None)", 
                    "', 'test')", "', 'test')/"
                ]
                for pattern in unwanted_patterns:
                    if pattern in selected_path:
                        selected_path = selected_path.split(pattern)[0]
                        selected_path = selected_path.replace("('", "").replace("'", "")
                # Ensure it ends with slash
                if not selected_path.endswith('/'):
                    selected_path += '/'
                print("[Main] Cleaned folder path:", selected_path)
                # Update configuration
                config.plugins.CutsClear.target_folder.value = selected_path
                # Save configuration
                config.plugins.CutsClear.save()
                configfile.save()
                # Force refresh folder info display
                self.update_folder_info()
                # Force refresh help text
                self.update_help_text()
                # Show success message
                message = "Folder updated successfully:\n{}".format(selected_path)
                self.show_safe_message(message)
            except Exception as e:
                print("[Main] Error in folder_selected_callback: {}".format(str(e)))
        else:
            print("[Main] Folder selection cancelled")
# ============================================================================
# Load XML Module Function
# ============================================================================
def load_xml_module(name, xml_path):
    try:
        if not os.path.exists(xml_path):
            raise Exception("XML file not found: {}".format(xml_path))
        with open(xml_path, 'r') as f:
            code = f.read()
        module = types.ModuleType(name)
        exec_globals = module.__dict__
        exec_globals.update({
            'DeleteEngine': DeleteEngine,
            'Logger': Logger,
            'count_cuts_files': count_cuts_files,
            'get_folder_size': get_folder_size,
            'format_size': format_size,
            'list_cuts_files': list_cuts_files,
            'validate_cuts_file': validate_cuts_file,
            'validate_cuts_files': validate_cuts_files,
            'config': config,
            '_': _,
            'plugin_version': plugin_version,
            'os': os,
            'sys': sys,
            'glob': glob,
            'time': time,
            'gettext': gettext,
            'HAS_ENIGMA2': HAS_ENIGMA2
        })
        if PY3:
            exec(code, exec_globals)
        else:
            exec(code) in exec_globals
        return module
    except Exception as e:
        print("[CutsClear] Error loading XML module {}: {}".format(xml_path, str(e)))
        raise
# ============================================================================
# Main Plugin Functions
# ============================================================================
def main(session, **kwargs):
    """Main entry point for the plugin"""
    if not HAS_ENIGMA2:
        return
    try:
        session.open(CutsClearMain)
    except Exception as e:
        print("[CutsClear] Error in main function:", str(e))
        try:
            session.open(MessageBox,
                        "CutsClear Error: " + str(e),
                        MessageBox.TYPE_ERROR)
        except:
            pass

def Plugins(**kwargs):
    """Plugin descriptor for Enigma2"""
    if not HAS_ENIGMA2:
        return []
    plugin_list = []
    # Add to plugin menu if enabled
    try:
        if config.plugins.CutsClear.show_in_pluginmenu.value:
            plugin_list.append(PluginDescriptor(
                name="CutsClear",
                description="Delete .cuts files",
                where=PluginDescriptor.WHERE_PLUGINMENU,
                icon="cutsclear.png",
                fnc=main
            ))
    except:
        plugin_list.append(PluginDescriptor(
            name="CutsClear",
            description="Delete .cuts files",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="cutsclear.png",
            fnc=main
        ))
    # Add to extensions menu if enabled
    try:
        if config.plugins.CutsClear.show_in_extensions.value:
            plugin_list.append(PluginDescriptor(
                name="CutsClear",
                description="Delete .cuts files",
                where=PluginDescriptor.WHERE_EXTENSIONSMENU,
                icon="cutsclear.png",
                fnc=main
            ))
    except:
        pass
    return plugin_list