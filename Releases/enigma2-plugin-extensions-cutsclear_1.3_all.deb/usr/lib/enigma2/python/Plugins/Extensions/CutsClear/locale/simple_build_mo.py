#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function

# NOTE:
# The lines below were part of an old shell helper and are kept (commented)
# to avoid removing any content from the original file.
# cat > simple_build_mo.py << 'EOF'
# EOF
# python simple_build_mo.py

import os
import sys
import struct


def _unescape_quoted(s):
    """Convert a quoted PO string line into a Python unicode string."""
    # s includes the surrounding quotes
    try:
        # Decode escape sequences like \n, \t, \xNN, \uNNNN
        return s[1:-1].encode("utf-8").decode("unicode_escape")
    except Exception:
        return s[1:-1]


def po_to_mo_bytes(po_text):
    """Compile .po content into a valid GNU gettext .mo (msgfmt-like)."""
    entries = []
    msgid = None
    msgstr = None
    state = None

    def commit():
        if msgid is None or msgstr is None:
            return
        entries.append((msgid, msgstr))

    for raw in po_text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue

        if line.startswith("msgid "):
            commit()
            state = "msgid"
            msgid = _unescape_quoted(line[5:].strip())
            msgstr = ""
            continue

        if line.startswith("msgstr "):
            state = "msgstr"
            msgstr = _unescape_quoted(line[6:].strip())
            continue

        if line.startswith('"'):
            if state == "msgid":
                msgid += _unescape_quoted(line)
            elif state == "msgstr":
                msgstr += _unescape_quoted(line)

    commit()

    # Sort by msgid for deterministic output
    entries.sort(key=lambda x: x[0])

    ids = [e[0].encode("utf-8") for e in entries]
    strs = [e[1].encode("utf-8") for e in entries]
    count = len(entries)

    # Header (7 * 4 bytes)
    # magic, revision, num strings, off orig table, off trans table, hash size, hash offset
    header_size = 7 * 4
    orig_table_offset = header_size
    trans_table_offset = header_size + (count * 8)

    # String data starts after both tables
    string_data_offset = header_size + (count * 8 * 2)

    # Build offset tables
    orig_offsets = []
    trans_offsets = []

    o_offset = string_data_offset
    for s in ids:
        orig_offsets.append((len(s), o_offset))
        o_offset += len(s) + 1

    t_offset = o_offset
    for s in strs:
        trans_offsets.append((len(s), t_offset))
        t_offset += len(s) + 1

    output = struct.pack("Iiiiiii", 0x950412de, 0, count, orig_table_offset, trans_table_offset, 0, 0)

    for length, offset in orig_offsets:
        output += struct.pack("ii", length, offset)

    for length, offset in trans_offsets:
        output += struct.pack("ii", length, offset)

    for s in ids:
        output += s + b"\0"

    for s in strs:
        output += s + b"\0"

    return output


def create_mo_file(po_file, mo_file):
    """Create a .mo file from a .po file."""
    try:
        with open(po_file, "rb") as f:
            po_text = f.read().decode("utf-8", "replace")

        mo_bytes = po_to_mo_bytes(po_text)

        with open(mo_file, "wb") as f:
            f.write(mo_bytes)

        print("Created .mo file: {0}".format(mo_file))

    except Exception as e:
        print("Error creating {0}: {1}".format(mo_file, str(e)))


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    for lang in ("ar", "en"):
        lc_dir = os.path.join(base_dir, lang, "LC_MESSAGES")

        # Build both names for maximum compatibility
        for domain in ("CutsClear", "CutClear"):
            po_path = os.path.join(lc_dir, domain + ".po")
            mo_path = os.path.join(lc_dir, domain + ".mo")

            if os.path.exists(po_path):
                create_mo_file(po_path, mo_path)
            else:
                print("Warning: {0} not found".format(po_path))


if __name__ == "__main__":
    main()
